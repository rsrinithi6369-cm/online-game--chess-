const board = document.getElementById("board");
const statusText = document.getElementById("status");
const resetBtn = document.getElementById("reset");

const pieces = {
  w: { king:"♔", queen:"♕", rook:"♖", bishop:"♗", knight:"♘", pawn:"♙" },
  b: { king:"♚", queen:"♛", rook:"♜", bishop:"♝", knight:"♞", pawn:"♟" }
};

let boardState, turn, selected;

function newGame() {
  boardState = [
    ["br","bn","bb","bq","bk","bb","bn","br"],
    ["bp","bp","bp","bp","bp","bp","bp","bp"],
    ["","","","","","","",""],
    ["","","","","","","",""],
    ["","","","","","","",""],
    ["","","","","","","",""],
    ["wp","wp","wp","wp","wp","wp","wp","wp"],
    ["wr","wn","wb","wq","wk","wb","wn","wr"]
  ];
  turn = "w";
  selected = null;
  drawBoard();
}

function drawBoard() {
  board.innerHTML = "";
  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const square = document.createElement("div");
      square.className = "square " + ((r+c)%2 ? "dark" : "light");
      if (selected && selected.r === r && selected.c === c) square.classList.add("selected");

      const piece = boardState[r][c];
      if (piece) {
        const color = piece[0];
        const type = piece[1];
        square.textContent = pieces[color][{
          k:"king", q:"queen", r:"rook", b:"bishop", n:"knight", p:"pawn"
        }[type]];
      }
      square.addEventListener("click", () => clickSquare(r,c));
      board.appendChild(square);
    }
  }
  statusText.textContent = turn === "w" ? "White's turn" : "Black's turn";
}

function clickSquare(r,c) {
  const piece = boardState[r][c];

  if (!selected) {
    if (piece && piece[0] === turn) {
      selected = {r,c};
      drawBoard();
    }
    return;
  }

  const from = selected;
  if (piece && piece[0] === turn) {
    selected = {r,c};
    drawBoard();
    return;
  }

  // Simple playable movement for a beginner project.
  // It is not a full chess rules engine.
  boardState[r][c] = boardState[from.r][from.c];
  boardState[from.r][from.c] = "";
  turn = turn === "w" ? "b" : "w";
  selected = null;
  drawBoard();
}

resetBtn.addEventListener("click", newGame);
newGame();
