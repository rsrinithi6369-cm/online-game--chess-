# Online Chess Game

A simple browser-based chess game created using HTML, CSS and JavaScript.

## Technologies
- HTML
- CSS
- JavaScript

## Features
- 8x8 chess board
- White and black chess pieces
- Turn indicator
- Select and move pieces
- New Game button
- Mobile-friendly layout

## How to run
Open `index.html` in a web browser.

## Project purpose
This project was created as a beginner-friendly web development project to practice HTML, CSS and JavaScript.
